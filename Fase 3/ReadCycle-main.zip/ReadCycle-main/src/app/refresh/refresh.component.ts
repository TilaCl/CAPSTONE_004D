import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-refresh',
  templateUrl: './refresh.component.html',
  styleUrls: ['./refresh.component.scss'],
})
export class RefreshComponent  {
  

  constructor() { }

  // handleRefresh(event: CustomEvent) {
  //   setTimeout(() => {
  //     // Any calls to load data go here
  //     event.target.complete();
  //   }, 2000);
  // }



}
