export const environment = {
  production: true,
  firebase :{
    apiKey: "AIzaSyDZz5djX38wbhWxiZHdAYrmheepxBw2aRE",
    authDomain: "readcycle-40682.firebaseapp.com",
    projectId: "readcycle-40682",
    storageBucket: "readcycle-40682.appspot.com",
    messagingSenderId: "781292521766",
    appId: "1:781292521766:web:a276386cec292329eb59e7",
    measurementId: "G-MYW2B9152P"
  }
};
